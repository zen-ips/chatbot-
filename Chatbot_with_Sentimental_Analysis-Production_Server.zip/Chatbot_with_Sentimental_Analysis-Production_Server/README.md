# Chatbot_with_Sentimental_Analysis
The Chatbot will analyse the sentiment of the User.The Sentimental Analysis Component will determine whether the user's message express a positive, negative or a neutral Sentiment.This project combines NLP techniques, Machine Learning Algorithms to find the sentiment of User.

# Run Locally
## 1. Create a Virtual Environment
```Python
python -m venv <Any_Name>
```
## 2. Installation of Dependancies
```pip
pip install -r Essentials.txt
```

## 3. Run the Application
```python
python app.py
```